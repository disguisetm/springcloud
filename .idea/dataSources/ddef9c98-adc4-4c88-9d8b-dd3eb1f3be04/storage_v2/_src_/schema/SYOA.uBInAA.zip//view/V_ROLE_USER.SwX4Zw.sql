create view V_ROLE_USER as
  SELECT r.id as role_id
       , r.name as role_name 
       , r.rtype as role_type
       , r.status as role_status
       , u.id as user_id
       , u.username as user_name
       , u.cnname as user_cnname
       , u.password as user_password
       , u.status as user_status
       , u.accexpire as accexpire
       , u.pwdexpire as pwdexpire
from priv_role_user ru, priv_role r, org_user u
where ru.userid=u.id and ru.roleid=r.id
/

